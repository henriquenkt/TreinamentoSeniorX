
/**
 * Nome da primitiva : createMergeHistoricalSalary
 * Nome do dominio : hcm
 * Nome do serviço : payroll
 * Nome do tenant : trn73393327
 **/


const axios = require('axios');
const moment = require('moment');

exports.handler = async event => {

    let body = parseBody(event);
    let tokenSeniorX = event.headers['X-Senior-Token'];
    // URL base para chamadas e header com token para passar na chamada
    const instance = axios.create({
        baseURL: 'https://platform-homologx.senior.com.br/t/senior.com.br/bridge/1.0/rest/',
        headers: {
          'Authorization': tokenSeniorX
        }
    });

  // Busca informação do colaborador - Valida demitidos
  let employeeId = body.employee.id;
  let resp = await instance.get(`/hcm/payroll/entities/employee/${employeeId}`);
  if(resp){
    if (resp.data.dismissaldate)
      return sendRes(400, 'Não é permitido alterações em colaboradores demitidos.');
  }

    // Busca motivo da alteração - Valida motivo da alteração
  let idMovimentation = body.movimentationReason.id;
  let response = await instance.get(`/hcm/payroll/entities/movimentationreason`);
  if(response){
    let found = response.data.contents.find(contents => contents.id == idMovimentation);
    if(found){
      let code = found.code ;
      if(code == 1){
        return sendRes(400, 'Para alterações salariais, o motivo não pode ser 1-Admissão.');
      }
    }
  }
  
  // Valida data de alteração
  if(body.dateWhen){
    if(body.dateWhen < moment().add(-1, 'days').format() + 1){
      return sendRes(400, 'Não é permitido alterações com data retroativa.');
    }
  }

 return sendRes(200,body);
};

// Converte body para json quando for string
const parseBody = (event) => {
    return typeof event.body === 'string' ?  JSON.parse(event.body) : event.body || {};
};

// Retorna 
const sendRes = (status, body) => {
    var response = {
      statusCode: status,
      headers: {
        "Content-Type": "application/json"
      },
      body: typeof body === 'string' ? body : JSON.stringify(body) 
    };
    return response;
};